#ifndef COMMON_H
#define COMMON_H
#include<jni.h>


/**
 * this file contains platform independent routines for implementing
 * the IRDA protocol.
 * 
 * @author F.Bator
 * @date 16.08.2005
 */

/******************************************************************************
 * Macros
 ******************************************************************************/
#define DEBUG_LEVEL_ERROR 1
#define DEBUG_LEVEL_INFO 2
#define DEBUG_LEBEL_DEBUG 3


/**
 * setup the number of debug messages shown.
 */
#define DEBUG_LEVEL 1



/******************************************************************************
 * structure definitions
 ******************************************************************************/



/**
 * this structure is internally used for holding discovery informations.
 */
struct device_info{

	/**
	 * unique device id
	 */
	unsigned char device_id[4];


	/**
	 * device name.
	 */
	char device_name[22];
	
};



/******************************************************************************
 * function definitions
 ******************************************************************************/


/**
 * converts a zero terminated string into an java array.
 *
 * @param env JNI Env
 * @param value zero terminated string
 * @return java char array
 */
jbyteArray convert_char2obj(JNIEnv* env,char* value);




/**
 * converts a byteArray of JNI to char* array.
 * @param env JNI Env
 * @param value JNI Byte Array
 * @param result buffer for result
 * @param len length of result buffer
 */
void convert_obj2char(JNIEnv* env,jbyteArray value,char* result,int len);


/**
 * this method converts the internal discovery_info structure to
 * a instance of info.ppp.irda.DiscoveryInfo[].
 *
 * @param env JNI Env
 * @param info array of discovery infos
 * @param info_count number of elements in array
 * @return instance
 * @throw java.io.IOException
 */
jobject convert_device_info2obj(JNIEnv* env,struct device_info* info,size_t info_count);



/**
 * converts a IP addr to an object.
 * 
 * @param env JNI Env
 * @param addr char array of size 4
 * @return java array representation or NULL on error.
 */
jbyteArray convert_addr2obj(JNIEnv* env,char* addr);



/**
 * converts a java byte array for addresses (4 byte) to a C - based version.
 * @param env JNI Env
 * @param addrObj java byte array 
 * @param addr char array of size 4
 */
void convert_obj2addr(JNIEnv* env,jbyteArray addrObj,char* addr);


/**
 * this method throws an java.io.IOException with the given message.
 * 
 * @param env JNI Env
 * @param message Message
 */ 
void throw_io_exception(JNIEnv* env, const char* message,...);


/**
 * this method throws an info.ppp.irda.DiscoveryException with the given message.
 * 
 * @param env JNI Env
 * @param message Message
 */ 
void throw_runtime_exception(JNIEnv* env, const char* message,...);


/**
 * shows a error message.
 */
void error_message(const char* message,...);


/**
 * shows a info message.
 */
void info_message(const char* message,...);



/**
 * shows a debug message.
 */
void debug_message(const char* message,...);



#endif
