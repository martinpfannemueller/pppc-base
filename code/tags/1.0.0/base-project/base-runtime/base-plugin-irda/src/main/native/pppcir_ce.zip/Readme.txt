This folder contains the source files for 
the native part of the 3PC IRDA library.

Using Microsoft Embedded Visual C++ 4.0 it
can be compiled for WinCE 4.2 and higher.

The same sources can be compiled for WinCE 
3.0 using Microsoft Embedded Visual Tools 
3.0.

To build it, start Microsoft Embedded Visual
C++ 4.0, load the project workspace and 
compile the dll.