#include "common.h"
#include "irdasocketimpl.h"

#include <windows.h>
#include <af_irda.h>

#pragma warning( disable : 4244 ) //waring for SOCKET to int conv

#pragma warning( disable : 4267 ) // warning for size_t to jsize conv


/**
 * Implementation of the irda socket library.
 * 
 * @author F.Bator
 * @date 12.08.2005
 */



/******************************************************************************
 * internal MACROS and constants
 ******************************************************************************/
#define DEVICELIST_LEN 20
#define DEVICE_DISCOVERY_RETRY 3


/******************************************************************************
 * internal prototypes
 ******************************************************************************/

/**
 * This function is called, after a DLL is loaded.
 * We initalize the WinSock API here.
 * @param hModule windows dll handle
 * @param ul_reason_for_call one of DLL_PROCESS_ATTACH/DETACH, DLL_THRREAD_ATTACH/DETACH
 *
 */
BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved);


/**
 * printout windows specific error messages.
 */
void error_message_windows();


/******************************************************************************
 * Implementation
 ******************************************************************************/
BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved){

	WSADATA WSAData;

    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
	

			if (WSAStartup(MAKEWORD(1,1), &WSAData) != 0){
				error_message("cannot initialize WinSock Library.");
			}

		break;
		
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}







void error_message_windows(){
/*
LPVOID lpMsgBuf;
int errCode;

errCode=WSAGetLastError();
FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS,
    NULL,errCode,0,(LPTSTR) &lpMsgBuf,0,NULL);

error_message("ErrorCode: %d, Message:%s",errCode,lpMsgBuf);
*/
}







/*
 * Class:     info_pppc_irsock_IRSocketImpl
 * Method:    nativeDiscover
 * Signature: (Ljava/io/FileDescriptor;)[Linfo/pppc/irsock/IRDevice;
 */
JNIEXPORT jobjectArray JNICALL Java_info_pppc_irsock_IRSocketImpl_nativeDiscover
(JNIEnv* env, jclass cl){

  SOCKET sock;                    // Socket bound to the server
  DEVICELIST devList;             // Device list
  int iDevListLen = sizeof (devList);
  int iCount = 0;                 // Number of retries
  unsigned int i;
  struct device_info* devices;
  jobjectArray result=NULL;

  WSASetLastError(0);
  // Create a socket that is bound to the server.
  if ((sock = socket (AF_IRDA, SOCK_STREAM, 0)) == INVALID_SOCKET){
	  error_message_windows();
	  throw_io_exception(env,"Could not create socket for discovery.");
	 return NULL;
  }

  // Initialize the number of devices to zero.
  devList.numDevice = 0;      
  while ( (devList.numDevice == 0) && (iCount <= DEVICE_DISCOVERY_RETRY))
  {
	//  printf("DISCOVERY: discover try %d...\n",iCount);
	  iDevListLen=sizeof(devList);
    // Retrieve the socket option.
    WSASetLastError(0);
    if (getsockopt (sock, SOL_IRLMP, IRLMP_ENUMDEVICES, 
                    (char *)&devList, &iDevListLen) == SOCKET_ERROR)
    {
	  error_message_windows();
	  throw_io_exception(env,"Could not perform device discovery.");
	  closesocket (sock);
      return NULL;
    }
    
    iCount++;
    // Wait one second before retrying.
    Sleep (1000);          
  }

  
  devices=(struct device_info*)malloc(sizeof(struct device_info)*devList.numDevice);

  for(i=0;i<devList.numDevice;i++){
	  memcpy(devices[i].device_id,devList.Device[i].irdaDeviceID,4);
	  strcpy(devices[i].device_name,devList.Device[i].irdaDeviceName);
  }

 
  result=convert_device_info2obj(env,devices,devList.numDevice);
  free(devices);
  return result;
}






/*
 * Class:     info_pppc_irsock_IRSocketImpl
 * Method:    nativeCreate
 * Signature: (Z)Ljava/io/FileDescriptor;
 */
JNIEXPORT jint JNICALL Java_info_pppc_irsock_IRSocketImpl_nativeCreate
(JNIEnv* env, jclass cl){
  SOCKET fd;
  jint result;
  
 
  WSASetLastError(0);
  fd = socket(AF_IRDA, SOCK_STREAM, 0);

  if (fd != SOCKET_ERROR){
 	  result=fd;
  }else{
    result = 0;
	error_message_windows();
	throw_io_exception(env,"Could not create socket.");
  }

  return result;  	
}




/*
 * Class:     info_pppc_irsock_IRSocketImpl
 * Method:    nativeBind
 * Signature: (Ljava/io/FileDescriptor;[BI)V
 */
JNIEXPORT void JNICALL Java_info_pppc_irsock_IRSocketImpl_nativeBind
(JNIEnv* env, jclass cl, jint fd, jbyteArray serviceNameObj){

   //int fd;
  int result;
  SOCKADDR_IRDA addr;

	if(fd<0){
		throw_io_exception(env,"Socket is not created.");
		return;
	}

  WSASetLastError(0);

  debug_message("calling bind...");

  memset(&addr, 0, sizeof(addr));
  addr.irdaAddressFamily=AF_IRDA;  

  convert_obj2char(env,serviceNameObj,addr.irdaServiceName,25);

  debug_message("bind: provide service %s",addr.irdaServiceName);
  
  result = bind(fd, (SOCKADDR*)&addr, sizeof(addr));

  if ( result == SOCKET_ERROR){
    error_message_windows();
	throw_io_exception(env, "Could not call bind.");
  }
  
}




/*
 * Class:     info_pppc_irsock_IRSocketImpl
 * Method:    nativeListen
 * Signature: (Ljava/io/FileDescriptor;I)V
 */
JNIEXPORT void JNICALL Java_info_pppc_irsock_IRSocketImpl_nativeListen
(JNIEnv* env, jclass cl, jint fd, jint backlog){
	
	int result;

	if(fd<0){
		throw_io_exception(env,"Socket is not created.");
		return;
	}

	WSASetLastError(0);	
	debug_message("start listing with backlog %d",backlog);
	result=listen(fd,backlog);
	if(result == SOCKET_ERROR){
		error_message_windows();
		throw_io_exception(env, "Could not call listen on socket.");		
	}
}





/*
 * Class:     info_pppc_irsock_IRSocketImpl
 * Method:    nativeAccept
 * Signature: (Ljava/io/FileDescriptor;ILjava/net/SocketImpl;)Ljava/io/FileDescriptor;
 */
JNIEXPORT jint JNICALL Java_info_pppc_irsock_IRSocketImpl_nativeAccept
(JNIEnv* env, jclass cl, jint fd){

	SOCKET client_fd;

	if(fd<0){
		throw_io_exception(env,"Socket is not created.");
		return -1;
	}

	WSASetLastError(0);

	debug_message("start accept");
	client_fd=accept(fd,0,0);
	if( client_fd == INVALID_SOCKET){
		error_message_windows();
		throw_io_exception(env,"Could not call accept on socket.");
		closesocket(client_fd);
		client_fd=0;
	}
	return client_fd;
}





/*
 * Class:     info_pppc_irsock_IRSocketImpl
 * Method:    nativeConnect
 * Signature: (Ljava/io/FileDescriptor;[BI)V
 */
JNIEXPORT void JNICALL Java_info_pppc_irsock_IRSocketImpl_nativeConnect
(JNIEnv* env, jclass cl, jint fd, jbyteArray devAddrObj, jbyteArray serviceNameObj){
	SOCKADDR_IRDA addr;
	SOCKET fd_client;

	if(fd<0){
		throw_io_exception(env,"Socket is not created.");
		return;
	}

	WSASetLastError(0);
	convert_obj2char(env,serviceNameObj,addr.irdaServiceName,25);
	convert_obj2addr(env,devAddrObj,addr.irdaDeviceID);
	addr.irdaAddressFamily=AF_IRDA;

	debug_message("connect: %d start connect to %s at device %d.%d.%d.%d",fd,addr.irdaServiceName,
		(int)addr.irdaDeviceID[0],(int)addr.irdaDeviceID[1],
		(int)addr.irdaDeviceID[2],(int)addr.irdaDeviceID[3]);

	fd_client = connect(fd, (const struct sockaddr *)&addr, sizeof(SOCKADDR_IRDA));

	if(fd_client == SOCKET_ERROR){
		error_message_windows();
		throw_io_exception(env,"cannot connect to remote service %s at device %d.%d.%d.%d",
			addr.irdaServiceName,addr.irdaDeviceID[0],addr.irdaDeviceID[1],
			addr.irdaDeviceID[2],addr.irdaDeviceID[3]);
	}
  
}




/*
 * Class:     info_pppc_irsock_IRSocketImpl
 * Method:    nativeAvailable
 * Signature: (Ljava/io/FileDescriptor;)I
 */
JNIEXPORT jint JNICALL Java_info_pppc_irsock_IRSocketImpl_nativeAvailable
(JNIEnv* env, jclass cl, jint fd){
  unsigned long res = 0;
  //throw_io_exception(env,"available is not implemented yet.");
  return (jint)res;	
}




/*
 * Class:     info_pppc_irsock_IRSocketImpl
 * Method:    nativeClose
 * Signature: (Ljava/io/FileDescriptor;Ljava/io/FileDescriptor;)V
 */
JNIEXPORT void JNICALL Java_info_pppc_irsock_IRSocketImpl_nativeClose
(JNIEnv* env , jclass cl, jint fd){
	int res;
	if(fd<0){
		return;
	}

	WSASetLastError(0);
	res = closesocket(fd);
    if (res < 0){
		error_message_windows();
    	throw_io_exception(env,"Could not call close.");
    }
  }
  



/*
 * Class:     info_pppc_irsock_IRSocketImpl
 * Method:    nativeRead
 * Signature: (I[BII)I
 */
JNIEXPORT jint JNICALL Java_info_pppc_irsock_IRSocketImpl_nativeRead
  (JNIEnv *env, jclass cl, jint fd, jbyteArray byteArray, jint off, jint len){
 	int res;
  jbyte *buffer;

	if(fd<0){
		throw_io_exception(env,"Socket is not open.");
		return -1;
	}

  buffer = (*env)->GetByteArrayElements(env,byteArray, 0);

  if(buffer==NULL){
	  throw_runtime_exception(env,"Could not handle buffer.");
	  return -1;
  }

  WSASetLastError(0);
  debug_message("read: ofs:%d, size:%d",off,len);

  res = recv(fd, buffer + off, len, 0);
  if(res==SOCKET_ERROR){
	error_message_windows();
	throw_io_exception(env,"Could not read.");
  }

  debug_message("read: finished reading.");
  (*env)->ReleaseByteArrayElements(env,byteArray, buffer, 0);


  return (jint) res;	
}




/*
 * Class:     info_pppc_irsock_IRSocketImpl
 * Method:    nativeWrite
 * Signature: (I[BII)V
 */
JNIEXPORT void JNICALL Java_info_pppc_irsock_IRSocketImpl_nativeWrite
  (JNIEnv *env, jclass cl, jint fd, jbyteArray byteArray, jint off, jint len){
  int ret;
  jbyte *data;
  int readLen = 0;

	if(fd<0){
		throw_io_exception(env,"Socket is not open.");
		return;
	}

  WSASetLastError(0);

  data = (*env)->GetByteArrayElements(env,byteArray, 0);
 if(data==NULL){
	  throw_runtime_exception(env,"Could not handle buffer.");
	  return;
  }
 
  readLen=0;
  debug_message("write: sending size:%d data, startting with ofs:%d",len,off);
  while (readLen < len){
	  debug_message("write: readlen: %d",readLen);
	  ret = send(fd, data + off + readLen, len - readLen, 0);
	  debug_message("write: read size: %d",ret);

      if (ret == SOCKET_ERROR) {	
		error_message_windows();
		throw_io_exception(env,"Could not write.");
		break;
	  } //else if(ret == 0){
		 // info_message("connection was closed.");
	  //}
	  readLen +=ret;
  }

  (*env)->ReleaseByteArrayElements(env,byteArray, data, 0);	
}


