#include "common.h"

#include<string.h>
#include<stdarg.h>

#pragma warning (disable: 4267) //warning conv size_t to jsize

/******************************************************************************
 * internal prototypes
 ******************************************************************************/
static void message(const char* level,const char* msg,va_list vargs);

/******************************************************************************
 * implementation
 ******************************************************************************/

jbyteArray convert_char2obj(JNIEnv* env,char* value){
	jcharArray result;
	jsize len=strlen(value); 

	result= (*env)->NewByteArray(env,len);
	(*env)->SetByteArrayRegion(env,result,0,len,value);
	return result;
}




jbyteArray convert_addr2obj(JNIEnv* env,char* addr){
	jcharArray result;

	result= (*env)->NewByteArray(env,4);
	(*env)->SetByteArrayRegion(env,result,0,4,addr);
	return result;
}



void convert_obj2addr(JNIEnv* env,jbyteArray value,char* addr){
	(*env)->GetByteArrayRegion(env,value,0,4,addr);
}




void convert_obj2char(JNIEnv* env,jbyteArray value,char* result,int len){
	jsize count;


	count=(*env)->GetArrayLength(env,value);
	count=(count>len)?len:count;

	(*env)->GetByteArrayRegion(env,value,0,count,result);
	result[count]=0;
}



jobject convert_device_info2obj(JNIEnv* env,struct device_info* info,size_t info_count){
	jclass element_class;
	jobjectArray result;
	jobject element_init;
	jobject element;
	jfieldID field_device_id;
	jfieldID field_device_name;
	unsigned int i;


	//create array
	element_class=(*env)->FindClass(env,"info/pppc/irsock/IRDevice");
	if(element_class==0){
		throw_runtime_exception(env,"class info.pppc.irsock.IRDevice not found.\n");
		return NULL;
	}

	field_device_id = (*env)->GetFieldID(env,element_class, "address", "[B");
	if(field_device_id==0){
		throw_runtime_exception(env,"field address of class info.pppc.irsock.IRDevice not found.");
		return NULL;
	}

	field_device_name = (*env)->GetFieldID(env, element_class, "name", "[B");
	if(field_device_name==0){
		throw_runtime_exception(env,"field name of class info.pppc.irsock.IRDevice not found.");
		return NULL;
	}
	element_init = (*env)->NewObject(env,element_class, (*env)->GetMethodID(env,element_class, "<init>", "()V"));

	result=(*env)->NewObjectArray(env,info_count,element_class,element_init);

	//fill array
	for(i=0;i<info_count;i++){
		element = (*env)->NewObject(env,element_class, (*env)->GetMethodID(env,element_class, "<init>", "()V"));

		(*env)->SetObjectField(env,element, field_device_id, convert_addr2obj(env,info[i].device_id));

		(*env)->SetObjectField(env,element,field_device_name,convert_char2obj(env,info[i].device_name));

		(*env)->SetObjectArrayElement(env,result,i,element);

	}

	return result;
}





void throw_io_exception(JNIEnv* env, const char* msg,...){
	char buf[255];
	va_list vargs;
	va_start(vargs,msg);
	message("IO EXCEPTION",msg,vargs);
	va_end(vargs);

	va_start(vargs,msg);
	vsprintf(buf,msg,vargs);
	va_end(vargs);
	(*env)->ThrowNew(env,(*env)->FindClass(env,"java/io/IOException"), buf);	

}


void throw_runtime_exception(JNIEnv* env, const char* msg,...){
	va_list vargs;
	char buf[255];

	va_start(vargs,msg);
	message("RUNTIME EXCEPTION",msg,vargs);
	va_end(vargs);


	va_start(vargs,msg);
	vsprintf(buf,msg,vargs);
	va_end(vargs);
	(*env)->ThrowNew(env,(*env)->FindClass(env,"java/lang/RuntimeException"), buf);	

}

static void message(const char* level,const char* msg,va_list vargs){
	char buf[255];
	vsprintf(buf,msg,vargs);
	printf("NATIVE LIBRARY - %s: %s\n",level,buf);
}





void debug_message(const char* msg,...){
#if (DEBUG_LEVEL > 2)
	va_list vargs;
	va_start(vargs,msg);
	message("DEBUG",msg,vargs);
	va_end(vargs);
#endif
}


void error_message(const char* msg,...){
#if (DEBUG_LEVEL > 0)
	va_list vargs;
	va_start(vargs,msg);
	message("ERROR",msg,vargs);
	va_end(vargs);
#endif
}


void info_message(const char* msg,...){
#if (DEBUG_LEVEL > 1)
	va_list vargs;
	va_start(vargs,msg);
	message("INFO",msg,vargs);
	va_end(vargs);
#endif
}


