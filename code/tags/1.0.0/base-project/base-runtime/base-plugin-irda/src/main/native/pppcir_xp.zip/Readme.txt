This folder contains the source files for 
the native part of the 3PC IRDA library.

Using Microsoft Visual Studio .NET it can 
be compiled for Windows NT and higher.

To build it, start Microsoft Visual Studio
.NET, load the solution workspace and 
compile the dll.